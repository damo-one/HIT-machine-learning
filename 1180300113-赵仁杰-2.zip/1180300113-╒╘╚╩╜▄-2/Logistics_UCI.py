'''
    @author:1180300113
    导入数据，观察自己写的梯度下降实现的逻辑回归正确率
    其中包括不带正确项以及带正确项
'''
import numpy as np
import math
import matplotlib.pyplot as plt
import pandas as pd
import random

#数据量
data = 150
#步长
alpha = 0.001
#设置迭代次数
max = 100000

#将生成的数据进行规范换
def data_normolize(x1,y1,x2,y2):
    #data*1的全0矩阵
    x0 = np.ones((data,1))*0
    # 合并x1,y1
    x1y1 = np.hstack((x1,y1))
    # data*1的全1矩阵
    list1 = np.ones((data,1))*1
    # 合并x2,y2
    x2y2 = np.hstack((x2,y2))
    # 生成2*data*1的全1矩阵
    list2 = np.ones((2*data,1))*1
    # 合并x1y1和x2y2
    data1 = np.vstack((x1y1,x2y2))
    # 生成[1,x1y1,x2y2]矩阵
    data1 = np.hstack((list2,data1))

    # 生成特征矩阵2data*1的
    label = np.vstack((x0,list1))
    return data1,label


#从文件中读取数据
def load_data(filename):
    file = open(filename)
    x = []
    #y是这里该数据的标签
    y = []
    for line in file.readlines():
        line = line.strip().split()
        x.append([1,float(line[0]),float(line[1])])
        y.append(float(line[-1]))
    #转化成相对应的矩阵
    x1 = np.mat(x)
    y1 = np.mat(y).T
    file.close
    return x1,y1
 #梯度下降
def grad(x1,y1,alpha,max):
    #随机生成对应的系数
    W = np.mat(np.random.randn(3,1))
    for i in range(0,max):
        H = 1/(1+np.exp(-1*x1*W))
        #根据数据生成对应的损失函数
        dw = x1.T*(H-y1)#3,1
        W = W - alpha*dw
    return W

#梯度下降+正则项
def grad_c(x1,y1,alpha,max):
    W = np.mat(np.random.randn(3,1))
    for i in range(0,max):
        #加入正则项
        W = W*(1-1e-4)
        H = 1/(1+np.exp(-1*x1*W))
        #损失函数
        dw = x1.T*(H-y1)#3,1
        W = W - alpha*dw
    return W

def test_correct(data,label,w0,w1,w2):
    data1 = np.size(label,0)
    print('data1',data1)
    x = 0.0
    y = 0.0
    for i in range(0,data1):
        if((w0+w1*data[:,1][i]+w2*data[:,2][i]>=0.0) and (label[i]==0)):
            x=x+1
        if((w0+w1*data[:,1][i]+w2*data[:,2][i]<=0.0) and (label[i]==1)):
            y =y+1
    return 1-(x+y)/data1
#读入文件，生成对应数据
data,label = load_data('data.txt')
#梯度下降生成对应参数
W = grad(data,label,alpha,max)
#梯度下降带正则项生成对应参数
W_C = grad_c(data,label,alpha,max)
print('W',W)
print('WC',W_C)


W0 = W[0,0]
W1 = W[1,0]
W2 = W[2,0]
WC0 = W_C[0,0]
WC1 = W_C[1,0]
WC2 = W_C[2,0]

# data文件夹里的数据的正确率
per = test_correct(data,label,W0,W1,W2)
#正确率
print('Accuracy:',per*100,'%')
# data文件夹里的数据的正确率
per_c = test_correct(data,label,WC0,WC1,WC2)
# 正确率
print('Accuracy+C:',per_c*100,'%')

plotx1 = np.arange(4,8,0.01)
plotx2 = -W0/W2 - W1/W2*plotx1
plotxWC2 = -WC0/WC2 - WC1/WC2*plotx1
plt.plot(plotx1,plotx2,c='r',label='fenjie')
plt.plot(plotx1,plotxWC2,c='b',label='fenjie+C')

# 文件中读取的数 y=0
plt.scatter(data[:,1][label==0].A,data[:,2][label==0].A,marker='^',c = 'r',label='y=0')
#  y=1
plt.scatter(data[:,1][label==1].A,data[:,2][label==1].A,c = 'g',label='y=1')

plt.grid()
plt.legend()
plt.show()