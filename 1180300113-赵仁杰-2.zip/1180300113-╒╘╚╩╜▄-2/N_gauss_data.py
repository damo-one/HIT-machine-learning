import numpy as np
import math
import matplotlib.pyplot as plt
import pandas as pd
import random

#数据量
data = 100
#步长
alpha = 0.001
#设置迭代次数
max = 10000

def gauss():
    # data*1的全3矩阵
    value = np.ones((data, 1)) * 3
    # data个高斯噪声data*1
    X1 = np.random.normal(0,2,data).reshape(data,1)
    #X2 = np.random.normal(5, 2, data).reshape(data, 1)
    # data个高斯噪声data*1
    Y1 = np.random.normal(0,2,data).reshape(data,1)
    # data个高斯噪声data*1
    X2 = X1+value
    # data个高斯噪声data*1
    Y2 = Y1+value
    return X1,Y1,X2,Y2

#将生成的数据进行规范换
def data_normolize(x1,y1,x2,y2):
    #data*1的全0矩阵
    x0 = np.ones((data,1))*0
    # 合并x1,y1
    x1y1 = np.hstack((x1,y1))
    # data*1的全1矩阵
    list1 = np.ones((data,1))*1
    # 合并x2,y2
    x2y2 = np.hstack((x2,y2))
    # 生成2*data*1的全1矩阵
    list2 = np.ones((2*data,1))*1
    # 合并x1y1和x2y2
    data1 = np.vstack((x1y1,x2y2))
    # 生成[1,x1y1,x2y2]矩阵
    data1 = np.hstack((list2,data1))

    # 生成特征矩阵2data*1的
    label = np.vstack((x0,list1))
    return data1,label

#梯度下降
def grad(x1,y1,alpha,max):
    #随机生成系数
    W = np.mat(np.random.randn(3,1))
    for i in range(0,max):
        H = 1/(1+np.exp(-1*x1*W))
        # 3,1，损失函数
        dw = x1.T*(H-y1)
        W = W - alpha*dw
    return W

#梯度下降+正则项
def grad_C(x1,y1,alpha,max):
    # 随机生成系数
    W = np.mat(np.random.randn(3,1))
    for i in range(0,max):
        # 正则项
        W = W*(1-1e-4)
        H = 1/(1+np.exp(-1*x1*W))
        # 3,1，损失函数
        dw = x1.T*(H-y1)
        W = W - alpha*dw
    return W

def test_correct(tx1,ty1,tx2,ty2,tlabel,w0,w1,w2,data):
    x = 0
    y = 0
    for i in range(0,data):
        if  (w0+w1*tx1[i]+w2*ty1[i]>=0.0):
            x = x+1
        if  (w0+w1*tx2[i]+w2*ty2[i]<=0.0):
            y = y+1
    return 1-(x+y)/(2*data)



 #训练集
x1,y1,x2,y2 = gauss()
#根据训练集生成对应矩阵以及标签
data1,label = data_normolize(x1,y1,x2,y2)
# 测试集
tx1,ty1,tx2,ty2 = gauss()
#根据测试集生成矩阵以及标签'''
tdata1,tlabel = data_normolize(tx1,ty1,tx2,ty2)



W = grad(data1,label,alpha,max)
#加入惩罚项的
W_C = grad_C(data1,label,alpha,max)
print('W',W)
print('WC',W_C)


W0 = W[0,0]
W1 = W[1,0]
W2 = W[2,0]
WC0 = W_C[0,0]
WC1 = W_C[1,0]
WC2 = W_C[2,0]

# 测试集正确率
per = test_correct(tx1,ty1,tx2,ty2,tlabel,W0,W1,W2,data)
print('Accuracy:',per*100,'%')
# 测试集+惩罚项正确率
per_c = test_correct(tx1,ty1,tx2,ty2,tlabel,WC0,WC1,WC2,data)
print('Accuracy+C:',per_c*100,'%')

plotx1 = np.arange(-5,7.5,0.01)
plotx2 = -W0/W2 - W1/W2*plotx1
plotxWC2 = -WC0/WC2 - WC1/WC2*plotx1
plt.plot(plotx1,plotx2,c='r',label='bianjie')
plt.plot(plotx1,plotxWC2,c='b',label='bianjie+C')

#测试集的点  y=0
plt.scatter(tx1,ty1,c = 'r',label='y=0')
# 测试集的点  y=1
plt.scatter(tx2,ty2,c = 'g',marker='^',label='y=1')


plt.grid()
plt.legend()
plt.show()